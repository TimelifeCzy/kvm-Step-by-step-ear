/* msmouse.c */
CharDriverState *qemu_chr_open_msmouse(QemuOpts *opts);
